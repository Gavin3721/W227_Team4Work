<template>
  <div>
    <h2>欢迎来到成都托儿所国际幼儿园管理平台</h2>
    <p>你可以进行相关的操作</p>
    <p>图表</p>
    <p>一共职工1000人</p>
    <p>学生20000人</p>
  </div>
</template>
<script>
export default {
  name: "Index",
  data: function () {
    return {}
  }
}
</script>
<style scoped>
</style>